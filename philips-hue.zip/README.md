# Controlling Philips Hue light using Alexa Echo Dot IoT


You can see demo video for [turn on](https://youtu.be/O9ctri6uEhc) and [set color](https://youtu.be/CcTMI_-VCKs) on youtube.
